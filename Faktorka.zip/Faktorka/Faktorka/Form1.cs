﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Faktorka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        Int64 n = 0;
        Int64 factorial = 1;

        private void button1_Click(object sender, EventArgs e)
        {
            try 
            {
                
                n = Int64.Parse(textBox1.Text);
               
                if (n < 0)
                    MessageBox.Show("Nie można policzyć silni z liczny ujemnej!", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                else if (n == 1)
                    textBox2.Text = 1.ToString();
                else
                {
                    for (int i = 1; i <= n; ++i)
                    {
                        factorial *= i;
                    }
                    textBox2.Text = factorial.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();
            factorial = 1;
            n = 0;
        }

        private void zamknijToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void otwórzToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (Silnia.ShowDialog() == DialogResult.OK)
                {
                    textBox2.Text = File.ReadAllText(Silnia.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Form1", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void SaveFile()
        {
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                    sw.Write(textBox1.Text);
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Form1", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        

        private void zapiszToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void nowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
                SaveFile();
            textBox1.Clear();
            textBox2.Clear();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void informacjeOSilniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://pl.wikipedia.org/wiki/Silnia");
        }

        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Łukasz Niedźwiadek ©IIIB 2018", "Autor", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
